#pragma once

#define DEFAULT_LOGSAVE 60

struct Inspection
{
	std::string ISPFILE;
	std::string ISPCMD;
};

struct Profile
{
	std::string EXEDIR;
	std::string USERID;
	std::string ERRLOGDIR;
	std::string SETTINGPATH;
	std::string TARGETDIR;
	std::string LOGDIR;
	std::string USERDIR;
	time_t STIME{};
	int LOGSAVE{ DEFAULT_LOGSAVE };
	bool DEBUG{false};
};

void GetErrMsg(std::string& msg, DWORD dwErr);

class CApplication
{
public:
	CApplication();
	virtual ~CApplication();

	bool Initialize(std::list<std::string>& cmdlines);
	void UnInitialize();

	void SetInstance(HINSTANCE hInstance)
	{
		m_hInstance = hInstance;
	};
	void SetPrevInstance(HINSTANCE hPrevInstance)
	{
		m_hPrevInstance = hPrevInstance;
	};
protected:
	ATOM MyRegisterClass(LPCSTR szTitle, LPCSTR szWindowClass);
	LRESULT WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
	UINT MainProcess(WPARAM wParam, LPARAM lParam);

	void InitializeProfile();
	bool UserIDCheck();
	int MergeSetting();
	int GetOwner();
	int GetTargetFiles(std::list<std::string>& trglist);
	int DoAction(std::string trgfile);
	int Execute(std::string cmd, LPDWORD pExitCode);
	int OldLogDelete();

	int ReadSetting(Profile& profile, std::map<std::string, Inspection>& inspection, LPCSTR SETTINGPATH);

	std::string ReplaceString(std::string src);
private:
	static LRESULT CALLBACK _WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
	HINSTANCE m_hInstance{nullptr};
	HINSTANCE m_hPrevInstance{ nullptr };
	HWND m_hWnd{ nullptr };

	HANDLE m_Mutex{ nullptr };

	Profile m_Profile;
	std::map<std::string, Inspection> m_Ispection;
	std::list<std::string> m_commandlines;
};

extern CApplication* pTheApp;


