#include "framework.h"
#include "Log.h"

#define TIMEBUFF_MAX 64

Log::Log()
{
	fopen_s(&m_pNormalLog, "C:\\Users\\81905\\source\\repos\\lh_file_check\\x64\\Debug\\log.log", "ab");
}

Log::~Log()
{
	fclose(m_pNormalLog);
}

void Log::putlog(LPCTSTR status, LPCTSTR user, LPCTSTR plog)
{
	CHAR timebuff[TIMEBUFF_MAX];

	struct tm when;
	time_t tme = time(NULL);
	_localtime64_s(&when, &tme);

	strftime(timebuff, sizeof(timebuff), "%Y/%m/%d\t%H:%I:%S", &when);

	fprintf(m_pNormalLog, "%s\t%s\t%s\t%s\n", timebuff, status, user, plog);
}

void Log::Normal(LPCTSTR user, LPCTSTR fmt, ...)
{
	LPTSTR buffer;
	va_list args;

	va_start(args, fmt);
	size_t len = _vscprintf(fmt, args);
	buffer = (char*)malloc(len * sizeof(TCHAR) + 1);
	if (nullptr == buffer)
	{
		return;
	}
	size_t vlen = vsprintf_s(buffer, len + 1, fmt, args);
	va_end(args);

	putlog("����", user,  buffer);
	free(buffer);
}

void Log::Info(LPCTSTR user, LPCTSTR fmt, ...)
{
}

void Log::Warn(LPCTSTR user, LPCTSTR fmt, ...)
{
}

void Log::Err(LPCTSTR user, LPCTSTR fmt, ...)
{
}

void Log::Debug(LPCTSTR user, LPCTSTR fmt, ...)
{
}
