// lh_file_check.cpp : �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "framework.h"
#include "lh_file_check.h"
#include "CApplication.h"

void wtoa(std::string& dest, LPCWSTR src)
{
    LPSTR buf;
    int dst_size, rc;

    rc = WideCharToMultiByte(CP_ACP, 0, src, -1, NULL, 0, NULL, NULL);
    if (rc == 0) {
        return;
    }

    dst_size = rc + 1;
    buf = (LPSTR)malloc(dst_size);
    if (buf == NULL) {
        return;
    }

    rc = WideCharToMultiByte(CP_ACP, 0, src, -1, buf, dst_size, NULL, NULL);
    if (rc == 0) {
        free(buf);
        return;
    }
    buf[rc] = '\0';

    dest = buf;

    free(buf);
}


int APIENTRY subMain(_In_ HINSTANCE hInstance,
    _In_opt_ HINSTANCE hPrevInstance,
    _In_ LPSTR    lpCmdLine,
    _In_ int       nCmdShow)
{
    CApplication theApp;
    std::list<std::string> cmdlines;

    pTheApp = &theApp;
    theApp.SetInstance(hInstance);
    theApp.SetPrevInstance(hPrevInstance);

    {
        int nArgs;
        LPWSTR* szArglist = CommandLineToArgvW(GetCommandLineW(), &nArgs);
        for (int i = 0; i < nArgs; i++)
        {
            std::string arg;
            wtoa(arg, szArglist[i]);
            cmdlines.push_back(arg);
        }
        LocalFree(szArglist);
    }

    // �A�v���P�[�V�����������̎��s:
    if (!theApp.Initialize(cmdlines))
    {
        theApp.UnInitialize();

        return 1;
    }

    MSG msg;

    // ���C�� ���b�Z�[�W ���[�v:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        DispatchMessage(&msg);
    }

    theApp.UnInitialize();

    return (int)msg.wParam;
}

int APIENTRY WinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    int ret = subMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow);

    _CrtSetReportMode(_CRT_WARN, _CRTDBG_MODE_DEBUG);
    _CrtDumpMemoryLeaks();

    return ret;
}
