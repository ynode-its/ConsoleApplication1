#pragma once
class Log
{
public:
	Log();
	virtual ~Log();

	void Normal(LPCTSTR user, LPCTSTR fmt, ...);
	void Info(LPCTSTR user, LPCTSTR fmt, ...);
	void Warn(LPCTSTR user, LPCTSTR fmt, ...);
	void Err(LPCTSTR user, LPCTSTR fmt, ...);
	void Debug(LPCTSTR user, LPCTSTR fmt, ...);
private:

	void putlog(LPCTSTR status, LPCTSTR user, LPCTSTR plog);

	FILE* m_pNormalLog;
	FILE* m_pErrLog;
};

