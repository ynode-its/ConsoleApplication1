#pragma once

#include "resource.h"

#define	FUNC_OK 0
#define	FUNC_NG 1
#define	FUNC_NOT_EXISIT 2

#define	WMSG_MAIN WM_USER + 1
