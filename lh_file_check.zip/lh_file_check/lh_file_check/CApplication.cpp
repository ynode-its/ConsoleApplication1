
#include "framework.h"
#include "lh_file_check.h"
#include "CApplication.h"
#include "Log.h"

#define MAX_LOADSTRING 100
#define SETTINGBUFF_MAX 1024

CApplication* pTheApp;

CApplication::CApplication()
{
}

CApplication::~CApplication()
{
}

bool CApplication::Initialize(std::list<std::string>& cmdlines)
{
    TCHAR szTitle[MAX_LOADSTRING];                  // �^�C�g�� �o�[�̃e�L�X�g
    TCHAR szWindowClass[MAX_LOADSTRING];            // ���C�� �E�B���h�E �N���X��

    m_commandlines = cmdlines;

    LoadString(m_hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadString(m_hInstance, IDC_LHFILECHECK, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(szTitle, szWindowClass);

    HWND hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr,m_hInstance, nullptr);

    if (!hWnd)
    {
        return FALSE;
    }

    ShowWindow(hWnd, SW_HIDE);

	return true;
}

void CApplication::UnInitialize()
{
}

LRESULT CApplication::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    try
    {
        switch (message)
        {
        case WMSG_MAIN:
            {
                UINT ret = MainProcess(wParam, lParam);
                if (nullptr != m_Mutex)
                {
                    CloseHandle(m_Mutex);
                    m_Mutex = nullptr;
                }
                PostMessage(m_hWnd, WM_DESTROY, ret, 0);
            }
            break;
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
        }
    }
    catch (const std::exception& ex)
    {
        DestroyWindow(hWnd);
    }
    return 0;
}

LRESULT CALLBACK CApplication::_WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    try
    {
        switch (message)
        {
        case WM_CREATE:
            pTheApp->m_hWnd = hWnd;
            PostMessage(hWnd, WMSG_MAIN, 0, 0);
            break;
        case WM_DESTROY:
            PostQuitMessage((int)wParam);
            break;
        default:
            return pTheApp->WndProc(hWnd, message, wParam, lParam);
        }
    }
    catch (const std::exception& ex)
    {
        DestroyWindow(hWnd);
    }

    return 0;
}

ATOM CApplication::MyRegisterClass(LPCSTR szTitle, LPCSTR szWindowClass)
{
    WNDCLASSEX wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = CApplication::_WndProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = m_hInstance;
    wcex.hIcon = LoadIcon(m_hInstance, MAKEINTRESOURCE(IDI_LHFILECHECK));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszMenuName = MAKEINTRESOURCE(IDC_LHFILECHECK);
    wcex.lpszClassName = szWindowClass;
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassEx(&wcex);
}

void CApplication::InitializeProfile()
{
    auto itr = m_commandlines.begin();
    size_t path_i = m_commandlines.front().find_last_of("\\");
    // �C���X�g�[���f�B���N�g���ݒ�
    m_Profile.EXEDIR = m_commandlines.front().substr(0, path_i);

    if (2 <= m_commandlines.size())
    {
        itr++;
        // ���[�UID�ݒ�
        m_Profile.USERID = *itr;
    }
    // �N�������ݒ�
    m_Profile.STIME = time(NULL);
    // �G���[���O�f�B���N�g���ݒ�
    m_Profile.ERRLOGDIR = m_Profile.EXEDIR;
    // �ݒ�t�@�C���p�X�ݒ�
    m_Profile.SETTINGPATH = m_Profile.EXEDIR + "\\lh_file_check.ini";

    if (3 <= m_commandlines.size())
    {
        // DEBUG Enable
        m_Profile.DEBUG = true;
    }
    else
    {
        std::error_code ec;
        bool result = std::filesystem::exists(m_Profile.EXEDIR + "\\lh_file_check.exe.DEBUG", ec);
        m_Profile.DEBUG = result;
    }
}

bool CApplication::UserIDCheck()
{
    if (0 == m_Profile.USERID.size())
    {
        // TODO ���O
        return FUNC_NG;
    }

    if (16 <= m_Profile.USERID.size())
    {
        // TODO ���O
        return FUNC_NG;
    }

    std::regex pattern("^[a-zA-Z0-9!-/:-@\\[-`{-~]+$");
    std::smatch sm;
    if (false == std::regex_match(m_Profile.USERID, sm, pattern))
    {
        // TODO ���O
        return FUNC_NG;
    }

    return FUNC_OK;
}

std::string CApplication::ReplaceString(
    std::string src   // �u�������Ώ�
)
{
    std::regex re1("%EXEDIR%");
    std::regex re2("%USERID%");

    auto rep1 = std::regex_replace(src, re1, m_Profile.EXEDIR);
    auto rep2 = std::regex_replace(rep1, re2, m_Profile.USERID);

    return rep2;
}

int CApplication::ReadSetting(Profile& profile, std::map<std::string, Inspection>& inspection, LPCSTR SETTINGPATH)
{
    CHAR str[SETTINGBUFF_MAX];
    size_t len;

    std::error_code ec;
    if (false == std::filesystem::exists(SETTINGPATH, ec))
    {
        // TODO ���O
        return FUNC_NOT_EXISIT;
    }

    len = GetPrivateProfileString("APPLICATION", "TARGETDIR", "", str, SETTINGBUFF_MAX, SETTINGPATH);
    if ((SETTINGBUFF_MAX - 1) == len)
    {
        // TODO ���O
        return FUNC_NG;
    }
    if (0 != strlen(str))
    {
        profile.TARGETDIR = ReplaceString(str);
    }

    len = GetPrivateProfileString("APPLICATION", "LOGDIR", "", str, SETTINGBUFF_MAX, SETTINGPATH);
    if ((SETTINGBUFF_MAX - 1) == len)
    {
        // TODO ���O
        return FUNC_NG;
    }
    if (0 != strlen(str))
    {
        profile.LOGDIR = ReplaceString(str);
    }

    len = GetPrivateProfileString("APPLICATION", "USERDIR", "", str, SETTINGBUFF_MAX, SETTINGPATH);
    if ((SETTINGBUFF_MAX - 1) == len)
    {
        // TODO ���O
        return FUNC_NG;
    }
    if (0 != strlen(str))
    {
        profile.USERDIR = ReplaceString(str);
    }

    int LOGSAVE = GetPrivateProfileInt("APPLICATION", "LOGSAVE", DEFAULT_LOGSAVE, SETTINGPATH);
    profile.LOGSAVE = LOGSAVE;
    if (0 > profile.LOGSAVE) profile.LOGSAVE = 0;

    int ISPCNT = GetPrivateProfileInt("INSPECTION", "ISPCNT", 0, SETTINGPATH);
    if (0 > ISPCNT)
    {
        ISPCNT = 0;
    }

    for (int i = 0; i < ISPCNT; i++)
    {
        Inspection isp;
        std::string ISPFILE("ISPFILE" + std::to_string(i + 1));
        std::string ISPCMD("ISPCMD" + std::to_string(i + 1));
        len = GetPrivateProfileString("INSPECTION", ISPFILE.c_str(), "", str, SETTINGBUFF_MAX, SETTINGPATH);
        if ((SETTINGBUFF_MAX - 1) == len)
        {
            // TODO ���O
            return FUNC_NG;
        }
        if (0 == strlen(str))
        {
            // TODO ���O
            continue;
        }
        isp.ISPFILE = ReplaceString(str);
        len = GetPrivateProfileString("INSPECTION", ISPCMD.c_str(), "", str, SETTINGBUFF_MAX, SETTINGPATH);
        if ((SETTINGBUFF_MAX - 1) == len)
        {
            // TODO ���O
            return FUNC_NG;
        }
        if (0 == strlen(str))
        {
            // TODO ���O
            continue;
        }
        isp.ISPCMD = ReplaceString(str);

        std::string s2 = isp.ISPFILE;

        std::transform(
            s2.begin(),
            s2.end(),
            s2.begin(),
            [](char c) { return std::tolower(c); }
        );

        inspection[s2] = isp;
    }

    return FUNC_OK;
}

int CApplication::MergeSetting()
{
    int ret;
    Profile user = m_Profile;
    std::map<std::string, Inspection> user_Inspection;

    ret = ReadSetting(m_Profile, m_Ispection, m_Profile.SETTINGPATH.c_str());
    if (FUNC_NG == ret)
    {
        // TODO �G���[���O
        return FUNC_NG;
    }

    user.SETTINGPATH = m_Profile.USERDIR + "\\lh_file_check.ini";
    ret = ReadSetting(user, user_Inspection, user.SETTINGPATH.c_str());
    if (FUNC_NG == ret)
    {
        // TODO �G���[���O
        return FUNC_NG;
    }
    else if (FUNC_NOT_EXISIT == ret)
    {
        return FUNC_OK;
    }
    if (false == user.TARGETDIR.empty())
    {
        m_Profile.TARGETDIR = user.TARGETDIR;
    }
    if (false == user.LOGDIR.empty())
    {
        m_Profile.LOGDIR = user.LOGDIR;
    }
    if (0 != user.LOGSAVE)
    {
        m_Profile.LOGSAVE = user.LOGSAVE;
    }
    if (0 < user_Inspection.size())
    {
        m_Ispection = user_Inspection;
    }

    if (m_Profile.TARGETDIR.empty())
    {
        // TODO ���O
        return FUNC_NG;
    }
    if (m_Profile.LOGDIR.empty())
    {
        // TODO ���O
        return FUNC_NG;
    }
    if (m_Profile.USERDIR.empty())
    {
        // TODO ���O
        return FUNC_NG;
    }
    if (0 == m_Ispection.size())
    {
        // TODO ���O
        return FUNC_NG;
    }

    return FUNC_OK;
}

void  aaaaa()
{
    STARTUPINFO si;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;

    PROCESS_INFORMATION pi;
    TCHAR cmd[] = "cmd /c forfiles /p C:\\Users\\81905\\source\\repos\\lh_file_check\\x64\\Debug\\aaa /m *.bmp /c \"cmd /c Del @path\" /d -7";

    CreateProcess(NULL, cmd, NULL, NULL,
        false, NORMAL_PRIORITY_CLASS, NULL, NULL, &si, &pi);

    // �s�v�ɂȂ����̂Ŕj��
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);;
}

void GetErrMsg(std::string& msg, DWORD dwErr)
{
    LPVOID lpMsgBuf;

    FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL,
        dwErr, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPSTR)&lpMsgBuf, 0, NULL);

    msg = (LPSTR)lpMsgBuf;
    LocalFree(lpMsgBuf);
}

int CApplication::Execute(std::string cmd, LPDWORD pExitCode)
{
    int ret = FUNC_NG;
    STARTUPINFO si;
    PROCESS_INFORMATION pi;

    ZeroMemory(&si, sizeof(si));
    ZeroMemory(&pi, sizeof(pi));

    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;


    CHAR cmm[SETTINGBUFF_MAX];
    if (-1 == sprintf_s(cmm, "cmd.exe /c %s", cmd.c_str()))
    {
        // ���O
        goto ERROR_FUNC;
    }

    if (false == CreateProcess(NULL, cmm, NULL, NULL,
                        false, NORMAL_PRIORITY_CLASS, NULL, NULL, &si, &pi))
    {
        // ���O
        std::string msg;
        GetErrMsg(msg, GetLastError());
        goto ERROR_FUNC;
    }

    WaitForSingleObject(pi.hProcess, INFINITE);

    GetExitCodeProcess(pi.hProcess, pExitCode);

    ret = FUNC_OK;

ERROR_FUNC:
    if (nullptr != pi.hThread)
    {
        CloseHandle(pi.hThread);
    }
    if (nullptr != pi.hProcess)
    {
        CloseHandle(pi.hProcess);
    }
    return ret;
}

int CApplication::GetOwner()
{
    return FUNC_OK;
}

int CApplication::GetTargetFiles(std::list<std::string>& trglist)
{
    WIN32_FIND_DATA finds;
    bool isNext = true;

    HANDLE hFind = FindFirstFile((m_Profile.TARGETDIR + "\\*").c_str(), &finds);
    if (hFind == INVALID_HANDLE_VALUE)
    {
        // ���O
        return FUNC_NOT_EXISIT;
    }

    do
    {
        if (FILE_ATTRIBUTE_DIRECTORY != (finds.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
        {
            std::string s2(finds.cFileName);
            std::transform(
                s2.begin(),
                s2.end(),
                s2.begin(),
                [](char c) { return std::tolower(c); }
            );

            auto iter = m_Ispection.find(s2);
            if (iter != m_Ispection.end())
            {
                trglist.push_back(s2);
            }
        }
        isNext = FindNextFile(hFind, &finds);
    } while (isNext == true);

    FindClose(hFind);

    if (0 == trglist.size())
    {
        return FUNC_NOT_EXISIT;
    }

    return FUNC_OK;
}

int CApplication::DoAction(std::string trgfile)
{
    int ret;
    DWORD ExitCode = 0;

    ret = Execute(m_Ispection[trgfile].ISPCMD, &ExitCode);
    if (FUNC_NG == ret)
    {
        // TODO ���O
        return FUNC_NG;
    }

    // TODO ���O ExitCode

    return FUNC_OK;
}

int CApplication::OldLogDelete()
{
    int ret;
    CHAR cmd[SETTINGBUFF_MAX];
    DWORD ExitCode = 0;

    if (0 == m_Profile.LOGSAVE)
    {
        return FUNC_OK;
    }
    if (0 == strlen(m_Profile.LOGDIR.c_str()))
    {
        // TODO ���O
        return FUNC_OK;
    }
    if (0 == strlen(m_Profile.USERID.c_str()))
    {
        // TODO ���O
        return FUNC_OK;
    }

    sprintf_s(cmd, "forfiles /p %s /m lh_file_check_%s_????????.log /c \"cmd /c Del @path\" /d -%d", m_Profile.LOGDIR.c_str(), m_Profile.USERID.c_str(), m_Profile.LOGSAVE);

    ret = Execute(cmd, &ExitCode);
    if (FUNC_NG == ret)
    {
        // TODO ���O
        return FUNC_NG;
    }
    // TODO ���O ExitCode


    return FUNC_OK;
}

UINT CApplication::MainProcess(WPARAM wParam, LPARAM lParam)
{
    int ret;
    std::list<std::string> trglist;

    InitializeProfile();

    ret = UserIDCheck();
    if (FUNC_NG == ret)
    {
        // TODO �G���[���O
        return FUNC_NG;
    }

    ret = MergeSetting();
    if (FUNC_NG == ret)
    {
        // TODO �G���[���O
        return FUNC_NG;
    }

    ret = GetOwner();
    if (FUNC_NG == ret)
    {
        // TODO �G���[���O
        return FUNC_NG;
    }

    ret = GetTargetFiles(trglist);
    if (FUNC_NG == ret)
    {
        // TODO �G���[���O
        return FUNC_NG;
    }
    else if (FUNC_OK == ret)
    {
        for (auto itr = trglist.begin(); itr != trglist.end(); itr++)
        {
            ret = DoAction(*itr);
            if (FUNC_NG == ret)
            {
                // TODO �G���[���O
                continue;
            }
        }
    }
    else if (FUNC_NOT_EXISIT == ret)
    {
        // TODO ���O
    }

    OldLogDelete();

    return FUNC_OK;
}
