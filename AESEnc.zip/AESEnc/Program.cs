﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace AESEnc
{
    internal class Program
    {
        // AES暗号化 key生成するための文字列 (256bitキー(32文字))
        private static string _aesKey = "";
        // AES暗号化 初期化ベクトルを生成するための文字列 (128bit(16文字))
        private static string _aesIv = "";

        static void Main(string[] args)
        {
            _aesKey = args[0];
            _aesIv = args[1];
            string data = args[2];

            var enc = AesEncrypt(data);

            var dec = AesDecrypt(enc);
            var i = data.CompareTo(dec);
            Console.WriteLine(_aesKey);
            Console.WriteLine(_aesIv);
            Console.WriteLine(data);
            Console.WriteLine(enc);
            Console.WriteLine(dec);
            Console.WriteLine(i);
            Console.ReadLine();
        }

        /// <summary>
        /// AESで暗号化する関数
        /// </summary>
        /// <param name="plain_text">暗号化する文字</param>
        /// <returns></returns>
        public static string AesEncrypt(string plain_text)
        {
            // 暗号化した文字列格納用
            string encrypted_str;

            // Aesオブジェクトを作成
            Aes aes = Aes.Create();
            {
                // Encryptorを作成
                ICryptoTransform encryptor =
                    aes.CreateEncryptor(Encoding.UTF8.GetBytes(_aesKey), Encoding.UTF8.GetBytes(_aesIv));
                // 出力ストリームを作成
                MemoryStream out_stream = new MemoryStream();
                // 暗号化して書き出す
                CryptoStream cs = new CryptoStream(out_stream, encryptor, CryptoStreamMode.Write);
                {
                    StreamWriter sw = new StreamWriter(cs);
                    // 出力ストリームに書き出し
                    sw.Write(plain_text);
                    sw.Close();
                }
                // Base64文字列にする
                byte[] result = out_stream.ToArray();
                encrypted_str = Convert.ToBase64String(result);
            }

            return encrypted_str;
        }


        /// <summary>
        /// AESで復号する関数
        /// </summary>
        /// <param name="base64_text">複合化する文字</param>
        /// <returns></returns>
        public static string AesDecrypt(string base64_text)
        {
            string plain_text;

            // Base64文字列をバイト型配列に変換
            byte[] cipher = Convert.FromBase64String(base64_text);

            // AESオブジェクトを作成
            Aes aes = Aes.Create();
            {
                // 復号器を作成
                ICryptoTransform decryptor =
                    aes.CreateDecryptor(Encoding.UTF8.GetBytes(_aesKey), Encoding.UTF8.GetBytes(_aesIv));
                // 復号用ストリームを作成
                MemoryStream in_stream = new MemoryStream(cipher);
                // 一気に復号
                CryptoStream cs = new CryptoStream(in_stream, decryptor, CryptoStreamMode.Read);
                StreamReader sr = new StreamReader(cs);
                plain_text = sr.ReadToEnd();
            }
            return plain_text;
        }
    }
}
